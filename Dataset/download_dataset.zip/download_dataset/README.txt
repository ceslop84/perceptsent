* In order to download run:
   python3 download.py 
